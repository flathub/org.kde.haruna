#define GLAD_EGL_IMPLEMENTATION
#include "common.h"
