#define PL_LIBAV_IMPLEMENTATION 0
#define PL_DAV1D_IMPLEMENTATION 0
#include <libplacebo/@header@>
