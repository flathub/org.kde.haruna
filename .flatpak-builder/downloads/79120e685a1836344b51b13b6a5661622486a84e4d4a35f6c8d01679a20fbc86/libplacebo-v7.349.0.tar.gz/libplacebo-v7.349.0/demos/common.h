// License: CC0 / Public Domain
#pragma once

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include <libplacebo/log.h>
#include <libplacebo/renderer.h>

#include "config_demos.h"
