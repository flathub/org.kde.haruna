// License: CC0 / Public Domain
#pragma once
#include "common.h"

const char *get_cache_dir(char (*buf)[512]);
